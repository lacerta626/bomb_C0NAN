import { call } from '../supabase-client.js';

const modal = document.querySelector('[data-game-notice]');
const codeInput = document.querySelector('#participant-code');
const nicknameInput = document.querySelector('#participant-nickname');
const status = document.querySelector('#code-status');
const remaining = document.querySelector('#code-remaining');
const confirmButton = document.querySelector('[data-modal-confirm]');

let selected = null;
let busy = false;

codeInput.addEventListener('input', () => {
  codeInput.value = codeInput.value.replace(/\D/g, '').slice(0, 4);
});

function normalizedNickname() {
  return nicknameInput.value.trim().replace(/\s+/g, ' ');
}

function validateInput() {
  const nickname = normalizedNickname();
  if (!/^\d{4}$/.test(codeInput.value)) throw Error('4자리 숫자 참가 코드를 입력해 주세요.');
  if (nickname.length < 2 || nickname.length > 12) throw Error('닉네임은 2~12자로 입력해 주세요.');
  return nickname;
}

async function check() {
  validateInput();
  const result = await call('check_code', { p_code: codeInput.value });
  if (result.nickname) nicknameInput.value = result.nickname;
  remaining.textContent = `EASY ${result.easy}/2 남음 · HARD ${result.hard}/2 남음`;
  return result;
}

document.querySelector('#check-code').addEventListener('click', async () => {
  status.textContent = '확인 중...';
  try {
    await check();
    status.textContent = '사용 가능한 참가 코드입니다.';
  } catch (error) {
    status.textContent = error.message;
  }
});

function closeModal() {
  modal.hidden = true;
  modal.classList.remove('is-open', 'is-easy', 'is-hard');
  document.body.classList.remove('is-modal-open');
  selected = null;
}

document.querySelectorAll('[data-modal-cancel],[data-modal-close]').forEach((element) => {
  element.addEventListener('click', closeModal);
});

document.querySelectorAll('.mode-card').forEach((card) => {
  card.addEventListener('click', async (event) => {
    event.preventDefault();
    if (busy) return;

    status.textContent = '';
    try {
      const result = await check();
      const mode = card.classList.contains('mode-card--hard') ? 'hard' : 'easy';
      if (result[mode] < 1) throw Error('해당 난이도의 기회를 모두 사용했습니다.');

      selected = { mode, target: card.getAttribute('href') };
      modal.hidden = false;
      modal.classList.add('is-open', `is-${mode}`);
      document.body.classList.add('is-modal-open');
    } catch (error) {
      status.textContent = error.message;
    }
  });
});

confirmButton.addEventListener('click', async () => {
  if (!selected || busy) return;
  busy = true;
  confirmButton.disabled = true;
  confirmButton.textContent = '게임 세션 생성 중...';

  try {
    const nickname = validateInput();
    const result = await call('start_game', {
      p_code: codeInput.value,
      p_mode: selected.mode,
      p_nickname: nickname,
    });

    const launchData = JSON.stringify({
      token: result.token,
      sessionId: result.session_id,
      expiresAt: Date.parse(result.expires_at),
    });
    const launchKey = `bomb-launch-${selected.mode}`;

    // Keep a same-origin fallback because some mobile/in-app browsers can
    // recreate sessionStorage while moving between the selector and runner.
    sessionStorage.setItem(launchKey, launchData);
    localStorage.setItem(launchKey, launchData);
    window.location.assign(selected.target);
  } catch (error) {
    closeModal();
    status.textContent = error.message;
    await check().catch(() => {});
  } finally {
    busy = false;
    confirmButton.disabled = false;
    confirmButton.textContent = '확인 후 게임 시작';
  }
});

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && !modal.hidden) closeModal();
});
