import { call } from '../supabase-client.js';

const mode = location.pathname.includes('/hard/') ? 'hard' : 'easy';
const frame = document.querySelector('#secured-game');
const storageKey = `bomb-launch-${mode}`;
let launch = null;
let submitted = false;

function showPanel(title, message, actions = '') {
  const panel = document.createElement('section');
  panel.className = 'fb-panel game-result-panel';
  panel.innerHTML = `<h1>${title}</h1><p>${message}</p>${actions}`;
  document.querySelector('.game-frame-shell').append(panel);
  return panel;
}

function showError(message) {
  frame.hidden = true;
  showPanel('MISSION ACCESS ERROR', message, '<a href="../index.html">코드 입력 화면으로 돌아가기</a>');
}

function clearStoredLaunch() {
  sessionStorage.removeItem(storageKey);
  localStorage.removeItem(storageKey);
}

function showResult(result) {
  frame.hidden = true;
  const title = result.success ? 'MISSION COMPLETE' : 'MISSION FAILED';
  const rank = result.rank ? `${result.rank}위` : '랭킹 제외';
  showPanel(
    title,
    `<strong>${result.nickname}</strong><br>남은 시간 ${Number(result.remaining_seconds).toFixed(2)}초<br>${mode.toUpperCase()} 현재 순위 ${rank}`,
    '<div class="game-result-actions"><a href="../../leaderboard.html">전체 랭킹 보기</a><a href="../../home.html">메인으로 돌아가기</a></div>',
  );
}

window.addEventListener('message', async (event) => {
  if (event.source !== frame.contentWindow || event.origin !== location.origin) return;
  if (event.data?.type !== 'AFTER1107_GAME_RESULT' || submitted || !launch) return;

  submitted = true;
  frame.style.opacity = '0.35';
  const saving = showPanel('기록 저장 중...', '게임 결과를 서버에서 검증하고 있습니다.');

  try {
    const result = await call('finish_game', {
      p_token: launch.token,
      p_success: Boolean(event.data.success),
      p_remaining_seconds: Number(event.data.remainingSeconds || 0),
      p_elapsed_seconds: Number(event.data.elapsedSeconds || 0),
    });
    clearStoredLaunch();
    saving.remove();
    showResult(result);
  } catch (error) {
    saving.querySelector('h1').textContent = '기록 저장 실패';
    saving.querySelector('p').textContent = `${error.message} 같은 세션으로 다시 저장하려면 페이지를 닫지 말고 잠시 후 새로고침하세요.`;
    submitted = false;
  }
});

(async () => {
  const raw = sessionStorage.getItem(storageKey) || localStorage.getItem(storageKey);
  try {
    if (!raw) throw Error('게임 선택 화면에서 참가 코드를 인증하고 시작해 주세요.');
    launch = JSON.parse(raw);
    sessionStorage.setItem(storageKey, raw);
    if (Date.now() > launch.expiresAt) throw Error('입장 유효시간이 만료되었습니다.');

    const session = await call('verify_launch', { p_token: launch.token, p_mode: mode });
    frame.addEventListener('load', () => {
      frame.contentWindow.postMessage({
        type: 'AFTER1107_AUTHORIZED_START',
        mode,
        timeLimitSeconds: session.time_limit_seconds,
      }, location.origin);
    }, { once: true });
    frame.src = frame.dataset.src;
  } catch (error) {
    showError(error.message);
  }
})();
