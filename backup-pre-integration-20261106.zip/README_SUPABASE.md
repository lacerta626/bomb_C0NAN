# AFTER 11:07 — Supabase 게임 랭킹 설정

## 1. 데이터베이스 설치

1. Supabase Dashboard → SQL Editor를 엽니다.
2. [supabase-setup.sql](./supabase-setup.sql) 전체를 실행합니다. 기존 참가 코드와 방명록 데이터는 삭제하지 않습니다.
3. Project Settings → API의 Project URL과 publishable/anon key를 `supabase-config.js`에 입력합니다.
4. `service_role` 또는 secret key는 브라우저 파일에 절대 넣지 않습니다.

## 2. 관리자 권한

Authentication → Users에서 관리자 계정을 만든 뒤 UUID를 등록합니다.

```sql
insert into public.admin_users(user_id)
values ('관리자-auth-user-uuid')
on conflict do nothing;
```

`admin-supabase.html`에서 해당 이메일과 비밀번호로 로그인합니다. 단순히 관리자 버튼을 숨기는 방식이 아니라 모든 관리자 RPC가 `auth.uid()`와 `admin_users`를 확인합니다.

## 3. GitHub Pages 배포

- 저장소의 정적 파일을 기존 방식대로 GitHub Pages에 배포합니다.
- `supabase-setup.sql`은 배포 대상에서 제외하는 것을 권장합니다.
- `supabase-config.js`의 publishable key는 공개되어도 되지만 RLS/RPC 권한을 제거하면 안 됩니다.
- Supabase Authentication의 Site URL과 Redirect URL에 실제 GitHub Pages 주소를 등록합니다.

## 4. 참가 코드와 닉네임

1. 관리자가 `admin-supabase.html`에서 코드를 생성하고 CSV를 내려받습니다.
2. 참가자는 미니게임 화면에서 4자리 코드와 2~12자 닉네임을 입력합니다.
3. 최초 게임 시작 시 닉네임이 코드에 고정됩니다.
4. 같은 코드를 다시 입력하면 저장된 닉네임이 자동 표시됩니다.
5. 참가자는 닉네임을 변경할 수 없고 관리자만 수정할 수 있습니다.
6. Easy와 Hard는 각각 최대 2회이며 시작 RPC의 DB 트랜잭션에서 즉시 차감됩니다.

## 5. 성공/실패 테스트

- Easy 또는 Hard를 시작하면 `game_launches`에 일회성 세션이 생성되는지 확인합니다.
- 새로고침 또는 직접 URL 접근으로 추가 횟수가 생성되지 않는지 확인합니다.
- 성공 시 결과 화면에 닉네임, 남은 시간, 난이도, 현재 순위가 표시되는지 확인합니다.
- 실패 시 `game_results.success=false`, `remaining_seconds=0`으로 저장되고 공개 랭킹에는 나오지 않는지 확인합니다.
- 같은 토큰으로 결과 저장을 반복해도 `session_id unique` 제약으로 중복 생성되지 않는지 확인합니다.

## 6. 랭킹 테스트

- `leaderboard.html`에서 Easy/Hard 전환을 확인합니다.
- 성공 기록만 남은 시간 내림차순으로 표시되는지 확인합니다.
- 같은 참가 코드의 동일 난이도 성공 기록은 가장 높은 점수 하나만 표시됩니다.
- 네트워크 탭의 `public_leaderboard` 응답에 참가 코드, session_id가 없는지 확인합니다.
- 새 기록은 결과 저장 후 즉시 반영되며 랭킹 페이지는 30초마다 자동 갱신됩니다.

## 7. 관리자 테스트

- 비관리자 Auth 계정으로 관리자 RPC 호출이 거부되는지 확인합니다.
- 코드/닉네임 검색, Easy/Hard 및 성공/실패 필터, 횟수 초기화, 코드 차단, 닉네임 수정, 결과 무효화, CSV 내보내기를 확인합니다.
- 결과를 무효 처리하면 공개 랭킹에서 제외되는지 확인합니다.

## 8. 보안과 부정행위 방지 한계

- 시도 차감, 세션 생성, 결과 중복 방지는 PostgreSQL RPC와 트랜잭션으로 처리됩니다.
- 공개 사용자는 원본 테이블을 직접 읽지 못하며 공개 랭킹 RPC만 호출할 수 있습니다.
- 결과 저장은 서버가 발급하고 검증한 일회성 토큰에만 허용됩니다.
- 단, 게임은 GitHub Pages에서 실행되는 클라이언트 JavaScript입니다. 브라우저 개발자 도구로 성공 여부나 남은 시간 값을 조작하는 행위를 완전히 막을 수 없습니다.
- `finish_game`은 허용 범위, 세션 상태, 중복 여부를 검증하지만 완전한 부정행위 방지가 필요하다면 게임 판정 로직 자체를 별도 신뢰 서버로 이전해야 합니다.
- 행사 운영 중에는 관리자 화면으로 비정상 기록을 모니터링하고 `is_valid=false`로 무효 처리하는 것을 권장합니다.
- Supabase 무료 프로젝트는 장기간 사용하지 않으면 일시 중지될 수 있습니다.

## 9. 주요 파일

- `supabase-setup.sql`: 테이블, RLS, 공개/관리자 RPC
- `minigame/minigame-access.js`: 코드·닉네임 확인과 세션 시작
- `minigame/game-runner-auth.js`: 실행 토큰 검증, 결과 저장, 결과 화면
- `leaderboard.html`, `leaderboard.js`: 공개 랭킹
- `admin-supabase.html`, `admin-supabase.js`: 관리자 랭킹 관리
