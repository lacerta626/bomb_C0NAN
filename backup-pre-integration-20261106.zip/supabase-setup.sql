-- AFTER 11:07: Supabase SQL Editor에서 한 번 실행하세요.
create extension if not exists pgcrypto;
create table if not exists public.participant_codes (
 code text primary key check (code ~ '^[0-9]{4}$'),
 easy_used integer not null default 0 check (easy_used between 0 and 2),
 hard_used integer not null default 0 check (hard_used between 0 and 2),
 disabled boolean not null default false,
 created_at timestamptz not null default now()
);
create table if not exists public.game_launches (
 token uuid primary key default gen_random_uuid(),
 code text not null references public.participant_codes(code),
 mode text not null check(mode in ('easy','hard')),
 expires_at timestamptz not null default (now()+interval '3 minutes'),
 verified_at timestamptz,
 created_at timestamptz not null default now()
);
create table if not exists public.guestbook (
 id bigint generated always as identity primary key,
 nickname text not null check(char_length(nickname) between 1 and 20),
 message text not null check(char_length(message) between 1 and 500),
 created_at timestamptz not null default now()
);
create table if not exists public.admin_users (user_id uuid primary key references auth.users(id));
alter table public.participant_codes enable row level security;
alter table public.game_launches enable row level security;
alter table public.guestbook enable row level security;
alter table public.admin_users enable row level security;
revoke all on public.participant_codes,public.game_launches,public.guestbook,public.admin_users from anon,authenticated;
-- RPC만 노출, 원본 테이블에 직접 접근 불가
create or replace function public.check_code(p_code text) returns jsonb language plpgsql security definer set search_path='' as $$
declare r public.participant_codes%rowtype;
begin
 if p_code !~ '^[0-9]{4}$' then raise exception '4자리 숫자를 입력해 주세요.'; end if;
 select * into r from public.participant_codes where code=p_code and not disabled;
 if not found then raise exception '등록되지 않았거나 차단된 코드입니다.'; end if;
 return jsonb_build_object('easy',2-r.easy_used,'hard',2-r.hard_used);
end $$;
create or replace function public.start_game(p_code text,p_mode text) returns jsonb language plpgsql security definer set search_path='' as $$
declare r public.participant_codes%rowtype; t uuid; ex timestamptz;
begin
 if p_code !~ '^[0-9]{4}$' or p_mode not in ('easy','hard') then raise exception '코드 또는 모드가 올바르지 않습니다.'; end if;
 select * into r from public.participant_codes where code=p_code for update;
 if not found or r.disabled then raise exception '사용할 수 없는 코드입니다.'; end if;
 if p_mode='easy' then
  if r.easy_used>=2 then raise exception 'Easy 기회를 모두 사용했습니다.'; end if;
  update public.participant_codes set easy_used=easy_used+1 where code=p_code;
 else
  if r.hard_used>=2 then raise exception 'Hard 기회를 모두 사용했습니다.'; end if;
  update public.participant_codes set hard_used=hard_used+1 where code=p_code;
 end if;
 insert into public.game_launches(code,mode) values(p_code,p_mode) returning token,expires_at into t,ex;
 return jsonb_build_object('token',t,'expires_at',ex);
end $$;
create or replace function public.verify_launch(p_token uuid,p_mode text) returns boolean language plpgsql security definer set search_path='' as $$
begin
 update public.game_launches set verified_at=now() where token=p_token and mode=p_mode and verified_at is null and expires_at>now();
 if not found then raise exception '유효하지 않거나 이미 사용한 입장권입니다.'; end if;
 return true;
end $$;
create or replace function public.list_guestbook(p_offset integer default 0) returns table(nickname text,message text,created_at timestamptz) language sql security definer set search_path='' as $$
 select g.nickname,g.message,g.created_at from public.guestbook g order by g.id desc limit 20 offset greatest(0,least(p_offset,10000));
$$;
create or replace function public.post_guestbook(p_nickname text,p_message text) returns boolean language plpgsql security definer set search_path='' as $$
begin
 if char_length(trim(p_nickname)) not between 1 and 20 or char_length(trim(p_message)) not between 1 and 500 then raise exception '닉네임 또는 메시지 길이를 확인하세요.'; end if;
 insert into public.guestbook(nickname,message) values(trim(p_nickname),trim(p_message));return true;
end $$;
create or replace function public.is_event_admin() returns boolean language sql security definer set search_path='' as $$
 select exists(select 1 from public.admin_users where user_id=(select auth.uid()));
$$;
create or replace function public.admin_create_codes(p_amount integer default 100) returns text[] language plpgsql security definer set search_path='' as $$
declare codes text[]:=array[]::text[]; c text; tries integer:=0;
begin
 if not public.is_event_admin() then raise exception '관리자 권한이 없습니다.'; end if;
 if p_amount<1 or p_amount>100 then raise exception '1~100개만 생성할 수 있습니다.'; end if;
 while cardinality(codes)<p_amount loop
  tries:=tries+1; if tries>100000 then raise exception '남은 코드가 부족합니다.'; end if;
  c:=lpad((floor(random()*10000)::integer)::text,4,'0');
  insert into public.participant_codes(code) values(c) on conflict do nothing;
  if found then codes:=array_append(codes,c); end if;
 end loop;
 return codes;
end $$;
create or replace function public.admin_list_codes() returns table(code text,easy_used integer,hard_used integer,disabled boolean) language plpgsql security definer set search_path='' as $$
begin
 if not public.is_event_admin() then raise exception '관리자 권한이 없습니다.'; end if;
 return query select p.code,p.easy_used,p.hard_used,p.disabled from public.participant_codes p order by p.code;
end $$;
create or replace function public.admin_update_code(p_code text,p_reset boolean default false,p_disabled boolean default null) returns boolean language plpgsql security definer set search_path='' as $$
begin
 if not public.is_event_admin() then raise exception '관리자 권한이 없습니다.'; end if;
 update public.participant_codes set easy_used=case when p_reset then 0 else easy_used end,hard_used=case when p_reset then 0 else hard_used end,disabled=coalesce(p_disabled,disabled) where code=p_code;
 if not found then raise exception '해당 코드가 없습니다.'; end if;
 return true;
end $$;
revoke execute on function public.is_event_admin() from public,anon;
revoke execute on function public.admin_create_codes(integer),public.admin_list_codes(),public.admin_update_code(text,boolean,boolean) from public,anon;
grant execute on function public.check_code(text),public.start_game(text,text),public.verify_launch(uuid,text),public.list_guestbook(integer),public.post_guestbook(text,text) to anon,authenticated;
grant execute on function public.admin_create_codes(integer),public.admin_list_codes(),public.admin_update_code(text,boolean,boolean) to authenticated;

-- =========================================================
-- Ranked game sessions (v2)
-- Re-running this section is safe and keeps existing codes.
-- =========================================================
alter table public.participant_codes add column if not exists nickname text;
do $$ begin
  if not exists (select 1 from pg_constraint where conname='participant_nickname_length') then
    alter table public.participant_codes add constraint participant_nickname_length
      check (nickname is null or char_length(nickname) between 2 and 12) not valid;
  end if;
end $$;

alter table public.game_launches add column if not exists session_id uuid default gen_random_uuid();
alter table public.game_launches add column if not exists nickname text;
alter table public.game_launches add column if not exists time_limit_seconds integer;
alter table public.game_launches add column if not exists attempt_number integer;
alter table public.game_launches add column if not exists finished_at timestamptz;

create unique index if not exists game_launches_session_id_key on public.game_launches(session_id);

create table if not exists public.game_results (
  id bigint generated always as identity primary key,
  session_id uuid not null unique,
  participant_code text not null references public.participant_codes(code),
  nickname text not null check (char_length(nickname) between 2 and 12),
  difficulty text not null check (difficulty in ('easy','hard')),
  attempt_number integer not null check (attempt_number between 1 and 2),
  started_at timestamptz not null,
  finished_at timestamptz not null default now(),
  time_limit_seconds integer not null check (time_limit_seconds > 0),
  remaining_seconds numeric(8,2) not null default 0,
  elapsed_seconds numeric(8,2) not null default 0,
  success boolean not null,
  is_valid boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.game_results enable row level security;
revoke all on public.game_results from anon, authenticated;

create or replace function public.check_code(p_code text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare r public.participant_codes%rowtype;
begin
  if p_code !~ '^[0-9]{4}$' then raise exception '4자리 숫자를 입력해 주세요.'; end if;
  select * into r from public.participant_codes where code=p_code and not disabled;
  if not found then raise exception '등록되지 않았거나 차단된 코드입니다.'; end if;
  return jsonb_build_object('easy',2-r.easy_used,'hard',2-r.hard_used,'nickname',r.nickname);
end $$;

create or replace function public.start_game(p_code text,p_mode text,p_nickname text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare
  r public.participant_codes%rowtype;
  t uuid;
  sid uuid;
  ex timestamptz;
  attempt integer;
  limit_seconds integer := case when p_mode='easy' then 90 else 120 end;
  clean_nickname text := regexp_replace(trim(p_nickname),'\s+',' ','g');
begin
  if p_code !~ '^[0-9]{4}$' or p_mode not in ('easy','hard') then raise exception '코드 또는 난이도가 올바르지 않습니다.'; end if;
  if char_length(clean_nickname) not between 2 and 12 then raise exception '닉네임은 2~12자로 입력해 주세요.'; end if;

  select * into r from public.participant_codes where code=p_code for update;
  if not found or r.disabled then raise exception '사용할 수 없는 코드입니다.'; end if;
  if r.nickname is not null and r.nickname <> clean_nickname then raise exception '이 코드에 등록된 닉네임과 일치하지 않습니다.'; end if;
  if r.nickname is null then update public.participant_codes set nickname=clean_nickname where code=p_code; end if;

  if p_mode='easy' then
    if r.easy_used>=2 then raise exception 'Easy 기회를 모두 사용했습니다.'; end if;
    attempt := r.easy_used + 1;
    update public.participant_codes set easy_used=attempt where code=p_code;
  else
    if r.hard_used>=2 then raise exception 'Hard 기회를 모두 사용했습니다.'; end if;
    attempt := r.hard_used + 1;
    update public.participant_codes set hard_used=attempt where code=p_code;
  end if;

  insert into public.game_launches(code,mode,nickname,time_limit_seconds,attempt_number)
  values(p_code,p_mode,clean_nickname,limit_seconds,attempt)
  returning token,session_id,expires_at into t,sid,ex;
  return jsonb_build_object('token',t,'session_id',sid,'expires_at',ex);
end $$;

create or replace function public.verify_launch(p_token uuid,p_mode text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare r public.game_launches%rowtype;
begin
  -- A runner page may initialize twice or be reloaded. Reuse the same
  -- unfinished verified session instead of consuming another attempt.
  select * into r from public.game_launches
  where token=p_token and mode=p_mode and verified_at is not null and finished_at is null;
  if found then
    return jsonb_build_object('session_id',r.session_id,'time_limit_seconds',r.time_limit_seconds);
  end if;

  update public.game_launches set verified_at=now()
  where token=p_token and mode=p_mode and verified_at is null and finished_at is null and expires_at>now()
  returning * into r;
  if not found then raise exception '유효하지 않거나 이미 사용된 게임 세션입니다.'; end if;
  return jsonb_build_object('session_id',r.session_id,'time_limit_seconds',r.time_limit_seconds);
end $$;

create or replace function public.finish_game(
  p_token uuid,
  p_success boolean,
  p_remaining_seconds numeric,
  p_elapsed_seconds numeric
) returns jsonb language plpgsql security definer set search_path='' as $$
declare r public.game_launches%rowtype; safe_remaining numeric; safe_elapsed numeric; server_elapsed numeric; player_rank bigint;
begin
  select * into r from public.game_launches where token=p_token for update;
  if not found or r.verified_at is null then raise exception '검증되지 않은 게임 세션입니다.'; end if;
  if r.finished_at is not null then
    with best as (select participant_code,max(remaining_seconds) score from public.game_results where difficulty=r.mode and success and is_valid group by participant_code),
    ranked as (select participant_code,row_number() over(order by score desc,participant_code) rank_no from best)
    select ranked.rank_no into player_rank from ranked where participant_code=r.code;
    return jsonb_build_object('nickname',r.nickname,'success',exists(select 1 from public.game_results where session_id=r.session_id and success),'remaining_seconds',coalesce((select remaining_seconds from public.game_results where session_id=r.session_id),0),'rank',player_rank);
  end if;

  server_elapsed := greatest(0,extract(epoch from (now()-r.verified_at)));
  safe_elapsed := greatest(server_elapsed,greatest(0,least(coalesce(p_elapsed_seconds,0),r.time_limit_seconds)));
  safe_remaining := case when p_success then greatest(0,least(coalesce(p_remaining_seconds,0),r.time_limit_seconds-safe_elapsed+1)) else 0 end;
  update public.game_launches set finished_at=now() where token=p_token;
  insert into public.game_results(session_id,participant_code,nickname,difficulty,attempt_number,started_at,time_limit_seconds,remaining_seconds,elapsed_seconds,success)
  values(r.session_id,r.code,r.nickname,r.mode,r.attempt_number,r.verified_at,r.time_limit_seconds,round(safe_remaining,2),round(safe_elapsed,2),p_success);

  with best as (select participant_code,max(remaining_seconds) score from public.game_results where difficulty=r.mode and success and is_valid group by participant_code),
  ranked as (select participant_code,row_number() over(order by score desc,participant_code) rank_no from best)
  select ranked.rank_no into player_rank from ranked where participant_code=r.code;
  return jsonb_build_object('nickname',r.nickname,'success',p_success,'remaining_seconds',round(safe_remaining,2),'rank',player_rank);
end $$;

create or replace function public.public_leaderboard(p_mode text)
returns table(rank_no bigint,nickname text,remaining_seconds numeric) language sql security definer set search_path='' stable as $$
  with best as (
    select distinct on (participant_code) participant_code,nickname,remaining_seconds,created_at
    from public.game_results
    where difficulty=p_mode and success and is_valid
    order by participant_code,remaining_seconds desc,created_at asc
  )
  select row_number() over(order by remaining_seconds desc,created_at asc),nickname,remaining_seconds
  from best order by remaining_seconds desc,created_at asc;
$$;

create or replace function public.admin_list_results()
returns table(id bigint,participant_code text,nickname text,difficulty text,attempt_number integer,remaining_seconds numeric,elapsed_seconds numeric,success boolean,is_valid boolean,started_at timestamptz,finished_at timestamptz)
language plpgsql security definer set search_path='' as $$
begin
  if not public.is_event_admin() then raise exception '관리자 권한이 없습니다.'; end if;
  return query select g.id,g.participant_code,g.nickname,g.difficulty,g.attempt_number,g.remaining_seconds,g.elapsed_seconds,g.success,g.is_valid,g.started_at,g.finished_at from public.game_results g order by g.created_at desc;
end $$;

drop function if exists public.admin_list_codes();
create function public.admin_list_codes()
returns table(code text,nickname text,easy_used integer,hard_used integer,disabled boolean)
language plpgsql security definer set search_path='' as $$
begin
  if not public.is_event_admin() then raise exception '관리자 권한이 없습니다.'; end if;
  return query select p.code,p.nickname,p.easy_used,p.hard_used,p.disabled from public.participant_codes p order by p.code;
end $$;

create or replace function public.admin_update_nickname(p_code text,p_nickname text)
returns boolean language plpgsql security definer set search_path='' as $$
begin
  if not public.is_event_admin() then raise exception '관리자 권한이 없습니다.'; end if;
  if char_length(trim(p_nickname)) not between 2 and 12 then raise exception '닉네임은 2~12자여야 합니다.'; end if;
  update public.participant_codes set nickname=trim(p_nickname) where code=p_code;
  update public.game_results set nickname=trim(p_nickname) where participant_code=p_code;
  return true;
end $$;

create or replace function public.admin_set_result_valid(p_id bigint,p_valid boolean)
returns boolean language plpgsql security definer set search_path='' as $$
begin
  if not public.is_event_admin() then raise exception '관리자 권한이 없습니다.'; end if;
  update public.game_results set is_valid=p_valid where id=p_id;
  return found;
end $$;

revoke execute on function public.start_game(text,text) from public,anon,authenticated;
revoke execute on function public.finish_game(uuid,boolean,numeric,numeric),public.public_leaderboard(text) from public;
grant execute on function public.check_code(text),public.start_game(text,text,text),public.verify_launch(uuid,text),public.finish_game(uuid,boolean,numeric,numeric),public.public_leaderboard(text) to anon,authenticated;
grant execute on function public.admin_list_codes(),public.admin_list_results(),public.admin_update_nickname(text,text),public.admin_set_result_valid(bigint,boolean) to authenticated;
