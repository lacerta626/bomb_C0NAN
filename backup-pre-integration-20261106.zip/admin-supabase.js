import { supabase, call, configured } from './supabase-client.js';

const $ = (id) => document.getElementById(id);
let codes = [];
let results = [];
let newCodes = [];

async function run(task) {
  try { $('status').textContent = '처리 중...'; await task(); $('status').textContent = '완료'; }
  catch (error) { $('status').textContent = error.message; }
}

function enabled(on) {
  ['create','refresh','results-csv'].forEach((id) => { $(id).disabled = !on; });
}

function downloadCsv(filename, header, rows) {
  const escape = (value) => `"${String(value ?? '').replaceAll('"','""')}"`;
  const csv = [header, ...rows].map((row) => row.map(escape).join(',')).join('\n');
  const url = URL.createObjectURL(new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' }));
  const link = document.createElement('a'); link.href = url; link.download = filename; link.click(); URL.revokeObjectURL(url);
}

function renderCodes() {
  const query = $('code-search').value.trim().toLowerCase();
  const filtered = codes.filter((item) => !query || item.code.includes(query) || (item.nickname || '').toLowerCase().includes(query));
  $('count').textContent = `총 ${filtered.length}개`;
  $('list').replaceChildren();
  filtered.forEach((item) => {
    const tr = document.createElement('tr');
    [item.code,item.nickname || '-',`${item.easy_used}/2`,`${item.hard_used}/2`,`${item.easy_used + item.hard_used}/4`,item.disabled ? '차단' : '활성'].forEach((value) => { const td=document.createElement('td'); td.textContent=value; tr.append(td); });
    const actions = document.createElement('td');
    const rename = document.createElement('button'); rename.textContent='닉네임 수정'; rename.onclick=()=>run(async()=>{const nickname=prompt('새 닉네임 (2~12자)',item.nickname || '');if(nickname===null)return;await call('admin_update_nickname',{p_code:item.code,p_nickname:nickname});await refresh();});
    const reset = document.createElement('button'); reset.textContent='횟수 초기화'; reset.onclick=()=>run(async()=>{if(!confirm('이 코드의 시도 횟수를 초기화할까요?'))return;await call('admin_update_code',{p_code:item.code,p_reset:true,p_disabled:null});await refresh();});
    const toggle = document.createElement('button'); toggle.textContent=item.disabled?'활성화':'차단'; toggle.onclick=()=>run(async()=>{await call('admin_update_code',{p_code:item.code,p_reset:false,p_disabled:!item.disabled});await refresh();});
    actions.append(rename,reset,toggle); tr.append(actions); $('list').append(tr);
  });
}

function renderResults() {
  const mode = $('mode-filter').value, result = $('result-filter').value, query = $('result-search').value.trim().toLowerCase();
  const filtered = results.filter((item) => (!mode || item.difficulty===mode) && (!result || (result==='success')===item.success) && (!query || item.participant_code.includes(query) || item.nickname.toLowerCase().includes(query)));
  $('results').replaceChildren();
  filtered.forEach((item) => {
    const tr=document.createElement('tr');
    [item.participant_code,item.nickname,item.difficulty,item.attempt_number,Number(item.remaining_seconds).toFixed(2),Number(item.elapsed_seconds).toFixed(2),item.success?'성공':'실패',item.is_valid?'유효':'무효',new Date(item.started_at).toLocaleString()].forEach((value)=>{const td=document.createElement('td');td.textContent=value;tr.append(td);});
    const actions=document.createElement('td');const toggle=document.createElement('button');toggle.textContent=item.is_valid?'무효 처리':'유효 복구';toggle.onclick=()=>run(async()=>{await call('admin_set_result_valid',{p_id:item.id,p_valid:!item.is_valid});await refresh();});actions.append(toggle);tr.append(actions);$('results').append(tr);
  });
}

async function refresh() {
  [codes,results] = await Promise.all([call('admin_list_codes'),call('admin_list_results')]);
  renderCodes(); renderResults();
}

$('login').onclick=()=>run(async()=>{if(!configured)throw Error('supabase-config.js 설정이 필요합니다.');const {error}=await supabase.auth.signInWithPassword({email:$('email').value,password:$('password').value});if(error)throw error;await call('admin_list_codes');enabled(true);await refresh();});
$('logout').onclick=()=>run(async()=>{await supabase.auth.signOut();enabled(false);codes=[];results=[];renderCodes();renderResults();});
$('create').onclick=()=>run(async()=>{if(!confirm('새 참가 코드 100개를 생성할까요?'))return;newCodes=await call('admin_create_codes',{p_amount:100});$('codes').textContent=newCodes.join(' / ');$('download').disabled=false;await refresh();});
$('download').onclick=()=>downloadCsv('after1107-new-codes.csv',['code'],newCodes.map((code)=>[code]));
$('results-csv').onclick=()=>downloadCsv('after1107-results.csv',['code','nickname','difficulty','attempt','remaining','elapsed','success','valid','started_at'],results.map((x)=>[x.participant_code,x.nickname,x.difficulty,x.attempt_number,x.remaining_seconds,x.elapsed_seconds,x.success,x.is_valid,x.started_at]));
$('refresh').onclick=()=>run(refresh);
['code-search','mode-filter','result-filter','result-search'].forEach((id)=>$(id).addEventListener('input',id==='code-search'?renderCodes:renderResults));

const { data: { session } } = configured ? await supabase.auth.getSession() : { data: { session: null } };
if (session) { enabled(true); await run(refresh); }
